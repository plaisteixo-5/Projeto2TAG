# Projeto2TAG
Segundo projeto de Teoria e Aplicação de Grafos na UnB.
Compilar utilizando:
	g++ -Wall -g -o projeto main.cpp
